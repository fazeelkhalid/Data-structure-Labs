# Lab 2 (Time complexity of non recursive functions)
 
